﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem7
{
    class Program
    {
        static void Main(string[] args)
        {
            int nthPrime = 0;
            int num = 1;
            while (true)
            {
                if (isPrime(num))
                {
                    nthPrime++;
                    if (nthPrime == 10001)
                    {
                        Console.WriteLine(num);
                        break;
                    }
                }
                num++;
            }
             
            
        }

        static bool isPrime(int num)
        {
            int count = 1;
            for (int i = 1; i < num; i++)
            {
                if (num % i > 0)
                {
                    count++;
                }
            }
            if (count+1 == num)
            {
                return true;
            }
            return false;
        }

    }
}
