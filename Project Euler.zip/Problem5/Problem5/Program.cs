﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem5
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i < 1000000000; i++)
            {
                int count = 0;
                for (int j = 1; j < 21; j++)
                {
                    if (i % j == 0)
                    {
                        count++;
                    }
                }
                if (count == 20)
                {
                    Console.WriteLine(i);
                    break;
                }
            }
        }
    }
}
