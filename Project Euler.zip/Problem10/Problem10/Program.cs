﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Problem10
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger sum = 0;
            for (int i = 2; i < 2000000; i++)
            {
                if (isPrime(i))
                {
                    sum += i;
                }
            }
            Console.WriteLine(sum);
        }

        static bool isPrime(int num)
        {
            int count = 1;
            for (int i = 1; i < num; i++)
            {
                if (num % i > 0)
                {
                    count++;
                }
            }
            if (count + 1 == num)
            {
                return true;
            }
            return false;
        }
    }
}
