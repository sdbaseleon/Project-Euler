﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem9
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int c = 1000; c > 2; c--)
            {
                for (int b = c - 1; b > 1; b--)
                {
                    for (int a = b - 1; a > 0; a--)
                    {
                        if ((squared(a) + squared(b) == squared(c)) && (a + b + c == 1000))
                        {
                            Console.WriteLine(a * b * c);
                        }
                    }
                }
            }
        }

        static int squared (int num)
        {
            return num * num;
        }
    }
}
